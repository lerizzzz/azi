from pathlib import Path
import json,zipfile,hashlib
R=Path(__file__).resolve().parents[1];P=R.parent;out=P/'exports/azi-remotion-layers-v01.zip'
files=[]
for name in ['README.md','package.json','package-lock.json','tsconfig.json','eslint.config.mjs','remotion.config.ts']:files.append(R/name)
for folder in ['src','tools','public','licenses']:
 files.extend(x for x in (R/folder).rglob('*') if x.is_file() and '__pycache__' not in str(x))
files.extend(x for x in (R/'review').glob('*.json'))
files += [P/'docs/SCREENPLAY_ALIENS_v02.md',P/'animation/film-v01/dialogue-source.json']
manifest=[]
for f in files:manifest.append({'path':str(f.relative_to(P)),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
(R/'source-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2));files.append(R/'source-manifest.json')
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for f in files:z.write(f,str(f.relative_to(P)))
 z.writestr('README-FIRST.txt','Послойный проект Remotion AZI.\nЧитайте remotion-film/README.md.\n55 графических слоёв, исходные атласы, риги Ази/мужчины, первая сцена, WAV и код включены.\nЛера, мастер и пришелец: подготовлены изображения слоёв, анимационные риги ещё предстоит собрать.\nЭто рабочая версия, полный фильм не завершён.\nNode modules и модели RHVoice не включены; npm ci восстановит JS-зависимости, готовые WAV включены.\n')
with zipfile.ZipFile(out) as z:assert z.testzip() is None
print('Source ZIP:',out.stat().st_size,'bytes;',len(files),'files')
