import { bundle } from "@remotion/bundler";
import {
  openBrowser,
  selectComposition,
  renderStill,
} from "@remotion/renderer";
import fs from "node:fs";
import path from "node:path";
const serveUrl = await bundle({
  entryPoint: path.resolve("src/index.ts"),
  outDir: path.resolve("review/bundle"),
  rspack: true,
  symlinkPublicDir: true,
});
const browser = await openBrowser("chrome", {
  browserExecutable: "/usr/bin/chromium",
  chromiumOptions: { gl: "swangle" },
});
try {
  const composition = await selectComposition({
    serveUrl,
    id: "Scene1",
    puppeteerInstance: browser,
  });
  for (const sec of [0, 3.5, 7, 14, 21, 25.95, 26.5, 27.6, 29.4, 32]) {
    await renderStill({
      serveUrl,
      composition,
      frame: Math.round(sec * 30),
      output: `review/scene1-${sec}.png`,
      imageFormat: "png",
      puppeteerInstance: browser,
    });
    console.log("review frame", sec);
  }
  const b = await selectComposition({
    serveUrl,
    id: "AziRig",
    puppeteerInstance: browser,
  });
  await renderStill({
    serveUrl,
    composition: b,
    frame: 0,
    output: "review/azi-skin-final.png",
    imageFormat: "png",
    puppeteerInstance: browser,
  });
  console.log("Control frames complete");
} finally {
  await browser.close({ silent: true });
}
