import fs from "node:fs";
import { spawnSync } from "node:child_process";
const input = process.argv[2] || "review/scene1-layered-v04.mp4";
fs.mkdirSync("out", { recursive: true });
const probe = JSON.parse(
  spawnSync("ffprobe", ["-v", "error", "-show_streams", "-of", "json", input], {
    encoding: "utf8",
  }).stdout,
);
const v = probe.streams.find((x) => x.codec_type === "video");
const matrix = v.color_space === "bt709" ? "bt709" : "bt601";
const range = v.color_range === "pc" ? "pc" : "tv";
const args = [
  "-y",
  "-loglevel",
  "error",
  "-i",
  input,
  "-vf",
  `scale=in_range=${range}:out_range=tv:in_color_matrix=${matrix}:out_color_matrix=bt709,format=yuv420p`,
  "-color_range",
  "tv",
  "-colorspace",
  "bt709",
  "-color_trc",
  "bt709",
  "-color_primaries",
  "bt709",
  "-c:v",
  "libx264",
  "-preset",
  "fast",
  "-threads",
  "4",
  "-profile:v",
  "baseline",
  "-level:v",
  "4.0",
  "-crf",
  "18",
  "-r",
  "30",
  "-c:a",
  "copy",
  "-movflags",
  "+faststart",
  "out/scene1-remotion-1080.mp4",
];
const r = spawnSync("ffmpeg", args, { stdio: "inherit" });
if (r.status !== 0) process.exit(r.status || 1);
console.log("Compatible master: out/scene1-remotion-1080.mp4");
