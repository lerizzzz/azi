from pathlib import Path
import subprocess,json,hashlib
from PIL import Image
R=Path(__file__).resolve().parents[1];movie=R/'out/scene1-remotion-1080.mp4'
probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(movie)]))
video=next(x for x in probe['streams'] if x['codec_type']=='video');audio=next(x for x in probe['streams'] if x['codec_type']=='audio')
assert video['width']==1080 and video['height']==1920 and video['r_frame_rate']=='30/1' and video['codec_name']=='h264' and video['pix_fmt']=='yuv420p'
assert int(video['nb_read_frames'])==1030;assert audio['codec_name']=='aac'
r=subprocess.run(['ffmpeg','-v','error','-i',str(movie),'-f','null','-'],capture_output=True,text=True,check=True);assert r.stderr==''
(R/'review/ffprobe.json').write_text(json.dumps(probe,indent=2))
timing=json.loads((R/'src/scene-timing.json').read_text());original=json.loads((R.parent/'animation/film-v01/dialogue-source.json').read_text())
for cue in [1,2,3,4]:assert ' '.join(x['text'] for x in timing['captions'] if x['cue']==cue)==original[cue-1]['text']
assert all(x['from']<x['to'] for x in timing['captions']);assert timing['captions'][-1]['to']<timing['duration']
(R/'review/decoded').mkdir(exist_ok=True)
frames=[0,15,90,195,420,630,779,795,828,885,960,1029];expr='+'.join(f'eq(n\\,{n})' for n in frames)
subprocess.run(['ffmpeg','-y','-loglevel','error','-i',str(movie),'-vf','select='+expr,'-fps_mode','vfr','-q:v','3',str(R/'review/decoded/frame-%02d.jpg')],check=True)
report={'engine':'Remotion 4.0.539','width':1080,'height':1920,'fps':30,'frames':1030,'duration_seconds':float(probe['format']['duration']),'codec':video['codec_name'],'pixel_format':video['pix_fmt'],'audio':audio['codec_name'],'full_decode_no_errors':True,'first_scene_dialogue_verbatim_and_ordered':True,'all_voice_tracks_fit':True,'full_bleed_composition':True,'mesh_character_animation':True,'synthetic_test_voice':True,'perceptual_audio_review_performed':False,'user_approval_received':False,'remaining_full_film_scenes':5,'sha256':hashlib.sha256(movie.read_bytes()).hexdigest()}
(R/'review/scene-validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False,indent=2))
