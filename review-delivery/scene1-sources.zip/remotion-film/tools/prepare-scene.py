from pathlib import Path
import json,subprocess,wave,math
import numpy as np
from scipy.signal import resample_poly
R=Path(__file__).resolve().parents[1];P=R.parent;SR=48000
engine=P/'.runtime/RHVoice/local/bin/RHVoice-test';V=R/'public/audio';V.mkdir(exist_ok=True)
parts=[
 (1,'АЗИ','Кисунь,',.25),(1,'АЗИ','если в Питер прилетели инопланетяне,',.3),(1,'АЗИ','главное — без паники.',.40),(1,'АЗИ','Сейчас расскажу, как не оказаться у них в гостях',.45),
 (2,'АЗИ','Правило первое.',.25),(2,'АЗИ','Не снимай НЛО.',.30),(2,'АЗИ','Даже если очень хочется выложить первой',.40),
 (3,'МУЖЧИНА','Ребят, вы просто не представляете, что сейчас происходит...',.15),
 (4,'АЗИ','Ну вот.',.38),(4,'АЗИ','Контент залетел.',.45),(4,'АЗИ','Автор тоже',.40)]
original=json.loads((P/'animation/film-v01/dialogue-source.json').read_text())
for n in [1,2,3,4]:assert ' '.join(t for i,s,t,pause in parts if i==n)==original[n-1]['text']
rows=[];cursor=.45
for k,(cue,speaker,text,pause) in enumerate(parts):
 if cue==4 and (not rows or rows[-1]['cue']!=4):cursor+=2.25
 inp=V/f's1-{k:02}.txt';out=V/f's1-{k:02}.wav';inp.write_text(text)
 subprocess.run([str(engine),'-p','Aleksandr-hq' if cue==3 else 'Elena','-r','88' if cue==3 else '70','-t','100' if cue==3 else '84','-i',str(inp),'-o',str(out)],check=True)
 with wave.open(str(out)) as w:rate=w.getframerate();a=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').astype(np.float32)/32768
 a=resample_poly(a,SR,rate);rms=np.sqrt(np.mean(a*a));a*=min(2.8,.12/max(rms,.001))
 row={'cue':cue,'speaker':speaker,'text':text,'from':cursor,'to':cursor+len(a)/SR,'file':'audio/'+out.name};rows.append(row);cursor=row['to']+pause
 print(k,cue,round(row['from'],2),round(row['to'],2),text,flush=True)
frames=math.ceil((cursor+1.2)*30);duration=frames/30
male=next(r for r in rows if r['cue']==3);maleEnd=male['to'];lift=maleEnd+.15;fall=lift+1.3;reaction=next(r for r in rows if r['cue']==4)['from']
edit={'fps':30,'width':1080,'height':1920,'frames':frames,'duration':duration,'captions':rows,'beats':{'ufoEnter':2.3,'rule':next(r for r in rows if r['cue']==2)['from'],'selfie':male['from'],'lift':lift,'fall':fall,'reaction':reaction,'exit':rows[-1]['to']+.5}}
(R/'src/scene-timing.json').write_text(json.dumps(edit,ensure_ascii=False,indent=2));(R/'public/scene-timing.json').write_text(json.dumps(edit,ensure_ascii=False,indent=2))
total=round(SR*duration);mix=np.zeros(total,np.float32);rng=np.random.default_rng(48)
def add(t,x,g=1):
 i=round(t*SR);end=min(total,i+len(x));mix[i:end]+=x[:end-i]*g
def tone(t,d,f,g=.02,dec=2):
 z=np.arange(round(d*SR))/SR;add(t,np.sin(2*np.pi*f*z)*np.exp(-z*dec)*np.minimum(1,z/.01),g)
def whoosh(t,d=.25,g=.06):
 z=np.arange(round(d*SR))/SR;x=np.convolve(rng.normal(0,1,len(z)),np.ones(12)/12,mode='same');add(t,x*np.sin(np.pi*z/d)**2,g)
for n,t in enumerate(np.arange(0,duration-.5,60/88)):
 tone(t,.5,[55,55,65.406,73.416][n%4],.022,5)
 if n%2==0:tone(t,.2,62,.035,20)
 if n%4==2:whoosh(t,.08,.025)
for t in [2.3,6.0,edit['beats']['rule'],edit['beats']['selfie'],lift,fall,edit['beats']['reaction']]:whoosh(t,.22,.045)
z=np.arange(round(SR*1.3))/SR;add(lift,np.sin(2*np.pi*(110*z+170*z*z))*np.sin(np.pi*z/1.3),.045)
tone(fall+.42,.2,70,.10,20)
for r in rows:
 with wave.open(str(R/'public'/r['file'])) as w:rate=w.getframerate();a=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').astype(np.float32)/32768
 a=resample_poly(a,SR,rate);a*=min(2.8,.12/max(.001,np.sqrt(np.mean(a*a))));add(r['from'],a)
mix[-4800:]*=np.linspace(1,0,4800);mix*=min(1,.9/max(abs(mix).max(),.001))
with wave.open(str(V/'scene1-mix.wav'),'wb') as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(SR);w.writeframes((mix*32767).astype('<i2').tobytes())
print('Scene1:',frames,'frames',duration,'seconds',edit['beats'])
