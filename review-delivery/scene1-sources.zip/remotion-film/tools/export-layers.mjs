import fs from "node:fs";
import path from "node:path";
import { spawnSync } from "node:child_process";
const defs = [
  ["azi/head-neutral", "azi/heads-atlas.png", [78, 20, 554, 588]],
  ["azi/head-blink", "azi/heads-atlas.png", [648, 21, 557, 589]],
  ["azi/head-surprise", "azi/heads-atlas.png", [78, 634, 560, 584]],
  ["azi/head-irritated", "azi/heads-atlas.png", [653, 633, 558, 587]],
  ["azi/torso", "azi/body-atlas.png", [148, 39, 350, 533]],
  ["azi/hair-back", "azi/body-atlas.png", [585, 16, 380, 590]],
  ["azi/arm-left-upper", "azi/body-atlas.png", [261, 612, 119, 374]],
  ["azi/arm-left-lower", "azi/body-atlas.png", [671, 610, 133, 425]],
  ["azi/arm-right-upper", "azi/body-atlas.png", [278, 1045, 116, 381]],
  ["azi/arm-right-lower", "azi/body-atlas.png", [684, 1049, 131, 456]],
  ["man/head-neutral", "man/body-atlas.png", [148, 8, 335, 412]],
  ["man/head-surprise", "man/body-atlas.png", [627, 8, 335, 412]],
  ["man/torso", "man/body-atlas.png", [122, 453, 447, 561]],
  ["man/arm-upper", "man/body-atlas.png", [721, 495, 180, 447]],
  ["man/arm-grip", "man/body-atlas.png", [216, 1033, 205, 449]],
  ["man/arm-open", "man/body-atlas.png", [696, 1030, 296, 485]],
  ["azi/leg-left-upper", "legs-atlas.png", [209, 4, 196, 359]],
  ["azi/leg-right-upper", "legs-atlas.png", [617, 4, 204, 360]],
  ["azi/leg-left-lower", "legs-atlas.png", [160, 368, 245, 393]],
  ["azi/leg-right-lower", "legs-atlas.png", [609, 363, 255, 397]],
  ["man/leg-left-upper", "legs-atlas.png", [211, 766, 181, 327]],
  ["man/leg-right-upper", "legs-atlas.png", [631, 766, 183, 329]],
  ["man/leg-left-lower", "legs-atlas.png", [130, 1098, 237, 422]],
  ["man/leg-right-lower", "legs-atlas.png", [655, 1098, 242, 425]],
  ["azi/arm-left-full", "azi/continuous-atlas.png", [269, 18, 151, 695]],
  ["azi/arm-right-full", "azi/continuous-atlas.png", [557, 19, 147, 693]],
  ["azi/leg-left-full", "azi/continuous-atlas.png", [107, 720, 304, 943]],
  ["azi/leg-right-full", "azi/continuous-atlas.png", [566, 721, 269, 927]],
  ["man/arm-grip-full", "man/continuous-atlas.png", [213, 16, 164, 668]],
  ["man/arm-open-full", "man/continuous-atlas.png", [642, 16, 269, 693]],
  ["man/leg-left-full", "man/continuous-atlas.png", [194, 720, 222, 798]],
  ["man/leg-right-full", "man/continuous-atlas.png", [609, 721, 229, 799]],
  ["alien/head", "alien/atlas.png", [179, 13, 300, 438]],
  ["alien/torso", "alien/atlas.png", [594, 51, 266, 407]],
  ["alien/arm-left-full", "alien/atlas.png", [256, 458, 104, 488]],
  ["alien/arm-right-full", "alien/atlas.png", [671, 458, 128, 489]],
  ["alien/leg-left-full", "alien/atlas.png", [260, 943, 120, 570]],
  ["alien/leg-right-full", "alien/atlas.png", [646, 943, 122, 571]],
  ["lera/head-closed", "lera/atlas.png", [96, 10, 419, 401]],
  ["lera/head-open", "lera/atlas.png", [552, 8, 416, 403]],
  ["lera/torso", "lera/atlas.png", [136, 424, 462, 590]],
  ["lera/arm-left-full", "lera/atlas.png", [690, 433, 213, 642]],
  ["lera/arm-right-full", "lera/atlas.png", [213, 1032, 279, 478]],
  ["props/mirror", "lera/atlas.png", [640, 1139, 192, 352]],
  ["master/head-neutral", "master/atlas.png", [166, 12, 273, 472]],
  ["master/head-speaking", "master/atlas.png", [635, 13, 274, 471]],
  ["master/torso", "master/atlas.png", [73, 498, 445, 578]],
  ["master/arm-left-full", "master/atlas.png", [649, 487, 311, 654]],
  ["master/arm-right-full", "master/atlas.png", [48, 1092, 515, 380]],
  ["props/tweezers", "master/atlas.png", [647, 1174, 286, 312]],
  ["props/ufo", "props/props-atlas.png", [12, 115, 915, 378]],
  ["props/phone", "props/props-atlas.png", [355, 653, 274, 486]],
  ["world/railing", "props/props-atlas.png", [13, 1138, 914, 460]],
];
const manifest = {};
for (const [id, source, b] of defs) {
  const out = `public/${id}.png`;
  fs.mkdirSync(path.dirname(out), { recursive: true });
  const [x, y, w, h] = b;
  const r = spawnSync(
    "ffmpeg",
    [
      "-y",
      "-loglevel",
      "error",
      "-i",
      `public/${source}`,
      "-vf",
      `crop=${w}:${h}:${x}:${y}`,
      "-frames:v",
      "1",
      out,
    ],
    { encoding: "utf8" },
  );
  if (r.status !== 0) throw new Error(r.stderr);
  manifest[id] = {
    file: `${id}.png`,
    width: w,
    height: h,
    source,
    sourceCrop: b,
  };
}
fs.writeFileSync("public/layers.json", JSON.stringify(manifest, null, 2));
fs.writeFileSync("src/layers.json", JSON.stringify(manifest, null, 2));
console.log(
  "Exported",
  Object.keys(manifest).length,
  "independent RGBA layers",
);
