import React from "react";
import {
  AbsoluteFill,
  Img,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
  delayRender,
  continueRender,
} from "remotion";
import { Audio } from "@remotion/media";
import { SkinnedRig } from "./SkinnedRig";
import timing from "./scene-timing.json";
import mouth from "./male-mouth-envelope.json";
const clamp = (v: number) => Math.max(0, Math.min(1, v));
const smooth = (v: number) => {
  v = clamp(v);
  return v * v * (3 - 2 * v);
};
if (typeof document !== "undefined") {
  const h = delayRender("Comic Cyrillic font");
  const f = new FontFace("AziComic", `url(${staticFile("fonts/Neucha.ttf")})`);
  f.load()
    .then((font) => {
      document.fonts.add(font);
      continueRender(h);
    })
    .catch((e) => {
      console.error(e);
      continueRender(h);
    });
}
const B = timing.beats;
const cuts = [
  { t: 0, view: "azi" },
  { t: 3, view: "wide" },
  { t: 6, view: "azi" },
  { t: 9.0, view: "ufo" },
  { t: B.rule, view: "man" },
  { t: B.rule + 3.1, view: "wide" },
  { t: B.selfie, view: "selfie" },
  { t: B.selfie + 2.3, view: "man" },
  { t: B.selfie + 4.3, view: "selfie" },
  { t: B.lift, view: "lift" },
  { t: B.fall, view: "phone" },
  { t: B.reaction, view: "azi" },
  { t: B.reaction + 1.35, view: "azi-close" },
  { t: B.reaction + 3.0, view: "azi" },
  { t: B.exit, view: "exit" },
];
const Camera: Record<string, { s: number; x: number; y: number }> = {
  azi: { s: 1.3, x: 0, y: -290 },
  "azi-close": { s: 1.62, x: 75, y: -380 },
  wide: { s: 1, x: 0, y: 0 },
  man: { s: 1.2, x: -210, y: -250 },
  selfie: { s: 1.68, x: -600, y: -540 },
  ufo: { s: 1.05, x: -35, y: 0 },
  lift: { s: 1, x: 0, y: 0 },
  exit: { s: 1.2, x: 55, y: -200 },
};
const WorldProps: React.FC<{ t: number; beam?: boolean }> = ({ t, beam }) => {
  const enter = smooth((t - B.ufoEnter) / 1.4),
    x = 80 + Math.sin(t * 0.7) * 7,
    y = -440 + enter * 540 + Math.sin(t * 0.8) * 5;
  return (
    <>
      <Img
        src={staticFile("props/ufo.png")}
        style={{
          position: "absolute",
          left: x,
          top: y,
          width: 1200,
          height: 496,
        }}
      />
      {beam && (
        <svg
          width="1080"
          height="1920"
          style={{ position: "absolute", top: 0, left: 0 }}
        >
          <defs>
            <linearGradient id="beam-fill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0" stopColor="#c2ffff" stopOpacity=".70" />
              <stop offset="1" stopColor="#63e3ed" stopOpacity=".15" />
            </linearGradient>
          </defs>
          <path d="M614 548L746 548L940 1860H410Z" fill="url(#beam-fill)" />
          <path
            d="M642 548H717L830 1860H510Z"
            fill="#b7ffff"
            opacity={0.14 + 0.04 * Math.sin(t * 3)}
          />
          {Array.from({ length: 20 }, (_, i) => (
            <ellipse
              key={i}
              cx={680 + Math.sin(i * 47) * 100}
              cy={600 + ((((i * 79 - t * 330) % 1140) + 1140) % 1140)}
              rx={1.7}
              ry={7}
              fill="#d7ffff"
              opacity={0.2 + 0.12 * Math.sin(i + t * 3)}
            />
          ))}
        </svg>
      )}
    </>
  );
};
const FreePhone: React.FC<{ t: number; close?: boolean }> = ({ t, close }) => {
  const release = B.lift + 0.06;
  if (t < release) return null;
  const impact = B.fall + 0.42,
    elapsed = t - release,
    flight = impact - release;
  let y = 1100 + 600 * Math.min(1, (elapsed / flight) ** 2);
  if (t > impact)
    y =
      1700 -
      Math.abs(Math.sin(Math.min(1, (t - impact) / 0.32) * Math.PI)) * 38;
  const x = 846 + 24 * clamp(elapsed / flight);
  const angle = elapsed * 520;
  if (close)
    return (
      <>
        <Img
          src={staticFile("world/kazan-clean.png")}
          style={{
            position: "absolute",
            width: 1080,
            height: 1920,
            objectFit: "cover",
            scale: 3.3,
            translate: "-100px -1450px",
          }}
        />
        <Img
          src={staticFile("props/phone.png")}
          style={{
            position: "absolute",
            left: 480,
            top: 700 + (y - 1500) * 2,
            width: 160,
            height: 284,
            rotate: `${angle}deg`,
            transformOrigin: "50% 60%",
          }}
        />
        {t >= impact && t < impact + 0.28 && (
          <svg width="1080" height="1920" style={{ position: "absolute" }}>
            <path
              d="M415 1430L366 1343M680 1425L735 1345M415 1510L347 1535M690 1510L756 1544"
              fill="none"
              stroke="#e9ddc5"
              strokeWidth="8"
            />
            <text
              x="730"
              y="1370"
              fill="#eee1c6"
              stroke="#20202b"
              strokeWidth="2"
              fontSize="75"
              fontFamily="AziComic"
              transform="rotate(12 730 1370)"
            >
              ТУК
            </text>
          </svg>
        )}
      </>
    );
  return (
    <Img
      src={staticFile("props/phone.png")}
      style={{
        position: "absolute",
        left: x,
        top: y,
        width: 54,
        height: 96,
        rotate: `${angle}deg`,
      }}
    />
  );
};
const WorldView: React.FC<{ t: number; view: string }> = ({ t, view }) => {
  const c = Camera[view] ?? Camera.azi;
  const lifting = t >= B.lift,
    p = clamp((t - B.lift) / 1.3),
    rise = p * p;
  const camS = c.s + Math.sin(t * 0.35) * 0.004;
  return (
    <AbsoluteFill style={{ overflow: "hidden", backgroundColor: "#5d6a7b" }}>
      {view === "phone" ? (
        <FreePhone t={t} close />
      ) : (
        <div
          style={{
            position: "absolute",
            width: 1080,
            height: 1920,
            scale: camS,
            translate: `${c.x + Math.sin(t * 0.4) * 3}px ${c.y}px`,
            transformOrigin: "0 0",
          }}
        >
          <Img
            src={staticFile("world/kazan-clean.png")}
            style={{
              position: "absolute",
              width: 1080,
              height: 1920,
              objectFit: "cover",
              scale: 1.055,
              translate: `${-Math.min(25, t * 2)}px 0px`,
              filter: "brightness(.84) saturate(.87)",
            }}
          />
          <WorldProps t={t} beam={lifting && t < B.fall + 0.4} />
          {t < B.fall && (
            <div
              style={{
                position: "absolute",
                width: 1080,
                height: 1920,
                clipPath: lifting
                  ? "polygon(0px 560px,1080px 560px,1080px 1920px,0px 1920px)"
                  : undefined,
              }}
            >
              <SkinnedRig
                who="man"
                time={t}
                x={680}
                y={1430 - rise * 970}
                scale={0.62 * (1 - 0.8 * rise)}
                lift={smooth((t - B.lift) / 0.32)}
                phone={t < B.lift + 0.06}
                filming={smooth((t - 2.4) / 1.0)}
                selfie={smooth((t - B.selfie + 0.6) / 0.6)}
                talk={
                  t >= B.selfie && t < B.lift
                    ? (mouth[Math.floor((t - B.selfie) * 30)] ?? 0)
                    : 0
                }
              />
            </div>
          )}
          <FreePhone t={t} />
          {view !== "ufo" && (
            <SkinnedRig
              who="azi"
              time={t}
              x={
                200 +
                100 * smooth(t / 2.5) +
                (view === "exit" ? 150 * smooth((t - B.exit) / 1.1) : 0)
              }
              y={1330 + (t < 2.51 ? Math.sin(t * 10) * 3 : 0)}
              scale={1}
              walking={t < 2.51}
              mode={t >= B.reaction ? "quip" : t > 2.8 ? "notice" : "read"}
              progress={
                t >= B.reaction
                  ? smooth((t - B.reaction) / 0.55)
                  : smooth((t - 2.8) / 0.7)
              }
              phone={t < B.exit + 0.3}
            />
          )}
          <Img
            src={staticFile("world/railing.png")}
            style={{
              position: "absolute",
              left: -300 - Math.min(180, t * 12),
              top: 1735,
              width: 1550,
              height: 780,
              opacity: 0.9,
            }}
          />
        </div>
      )}
    </AbsoluteFill>
  );
};
const wrap = (s: string, width: number) => {
  const words = s.split(" "),
    out: string[] = [];
  let line = "";
  for (const w of words) {
    if ((line + " " + w).length > width && line) {
      out.push(line);
      line = w;
    } else line = line ? line + " " + w : w;
  }
  if (line) out.push(line);
  return out;
};
const Caption: React.FC<{ t: number }> = ({ t }) => {
  const line = timing.captions.find((c) => t >= c.from && t < c.to);
  if (!line) return null;
  const displayText =
    line.cue === 3
      ? t - line.from < 3.15
        ? "Ребят, вы просто не представляете,"
        : "что сейчас происходит..."
      : line.text;
  const lines = wrap(displayText, line.cue === 3 ? 28 : 31);
  const wide = Math.min(
    750,
    Math.max(255, Math.max(...lines.map((s) => s.length)) * 19.5 + 80),
  );
  const h = lines.length * 49 + 64,
    x = line.cue === 4 ? Math.min(450, 1000 - wide) : 55,
    y = line.cue === 3 ? 720 : line.cue === 4 ? 1200 : 95;
  const a = smooth((t - line.from) / 0.12);
  return (
    <div
      style={{
        position: "absolute",
        left: x,
        top: y,
        width: wide,
        height: h,
        opacity: a,
        translate: `0px ${(1 - a) * 14}px`,
      }}
    >
      <svg
        width={wide + 15}
        height={h + 45}
        style={{ position: "absolute", overflow: "visible" }}
      >
        {line.cue < 3 ? (
          <path
            d={`M16 5L${wide - 12} 0L${wide} ${h - 7}L3 ${h}Z`}
            fill="#eee1c7"
            stroke="#15151e"
            strokeWidth="4"
          />
        ) : (
          <>
            <ellipse
              cx={wide / 2}
              cy={h / 2}
              rx={wide / 2}
              ry={h / 2}
              fill="#eee1c7"
              stroke="#15151e"
              strokeWidth="4"
            />
            <path
              d={
                line.cue === 3
                  ? `M${wide - 125} ${h - 20}L${wide - 30} ${h + 95}L${wide - 58} ${h - 30}`
                  : `M90 15L49 -35L125 5`
              }
              fill="#eee1c7"
              stroke="#15151e"
              strokeWidth="4"
            />
          </>
        )}
      </svg>
      <div
        style={{
          position: "absolute",
          inset: 0,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          fontFamily: "AziComic",
          fontSize: 44,
          lineHeight: "49px",
          color: "#23202b",
        }}
      >
        {lines.map((s, i) => (
          <div key={i}>{s}</div>
        ))}
      </div>
    </div>
  );
};
export const Scene1: React.FC = () => {
  const frame = useCurrentFrame(),
    { fps } = useVideoConfig(),
    t = frame / fps;
  let index = cuts.length - 1;
  while (index > 0 && t < cuts[index].t) index--;
  const cut = cuts[index],
    prev = cuts[Math.max(0, index - 1)];
  const a = index === 0 ? 1 : smooth((t - cut.t) / 0.24);
  const diagonal = index % 3 === 0;
  return (
    <AbsoluteFill style={{ backgroundColor: "#546274", overflow: "hidden" }}>
      <Audio src={staticFile("audio/scene1-mix.wav")} premountFor={fps} />
      {index > 0 && a < 1 && <WorldView t={t} view={prev.view} />}
      <div
        style={{
          position: "absolute",
          inset: 0,
          clipPath:
            a < 1
              ? diagonal
                ? `polygon(0 0,${a * 125}% 0,${a * 125 - 25}% 100%,0 100%)`
                : `inset(0 ${(1 - a) * 100}% 0 0)`
              : undefined,
        }}
      >
        <WorldView t={t} view={cut.view} />
      </div>
      <Caption t={t} />
      {t >= B.rule && t < B.rule + 1.2 && (
        <div
          style={{
            position: "absolute",
            left: 65,
            top: 430,
            fontFamily: "AziComic",
            fontSize: 52,
            color: "#f0e2ca",
            rotate: "-4deg",
            textShadow: "2px 3px #291c26",
          }}
        >
          ПРАВИЛО 1
        </div>
      )}
    </AbsoluteFill>
  );
};
