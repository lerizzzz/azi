import React from "react";
import {
  AbsoluteFill,
  Img,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import { Audio } from "@remotion/media";
import { SkinnedRig } from "./SkinnedRig";
import timing from "./scene2-timing.json";

const clamp = (v: number) => Math.min(1, Math.max(0, v));
const ease = (v: number) => {
  const p = clamp(v);
  return p * p * (3 - 2 * p);
};
const mix = (a: number, b: number, p: number) => a + (b - a) * ease(p);
const B = timing.beats;
export const scene2Cuts = [
  { t: 0, view: "street", edit: "cut" },
  { t: B.chase, view: "alien-street", edit: "slash" },
  { t: 2.85, view: "street-run", edit: "cut" },
  { t: B.enter, view: "court-wide", edit: "shutter" },
  { t: 5.15, view: "run", edit: "cut" },
  { t: 6.45, view: "alien-run", edit: "slash" },
  { t: B.quiet, view: "brake", edit: "cut" },
  { t: 8.75, view: "quiet", edit: "panel" },
  { t: 10.15, view: "smirk", edit: "cut" },
  { t: B.gate, view: "gate", edit: "shutter" },
  { t: 12.65, view: "annoyed", edit: "cut" },
  { t: B.door, view: "door", edit: "panel" },
  { t: B.sky, view: "look-up", edit: "cut" },
  { t: B.sky + 0.37, view: "sky", edit: "slash" },
  { t: B.beam, view: "beam", edit: "cut" },
  { t: B.quip, view: "reaction", edit: "panel" },
  { t: 20.0, view: "alien-return", edit: "cut" },
  { t: 21.05, view: "decision", edit: "cut" },
  { t: B.escape, view: "escape", edit: "slash" },
  { t: B.escape + 0.9, view: "slam", edit: "shutter" },
] as const;

type View = (typeof scene2Cuts)[number]["view"];
const cameras: Partial<Record<View, [number, number, number]>> = {
  "court-wide": [1, 540, 960],
  run: [1.55, 485, 1060],
  "alien-run": [1.95, 765, 940],
  brake: [1.62, 400, 1050],
  quiet: [1, 540, 960],
  smirk: [1.95, 470, 990],
  annoyed: [1.9, 420, 1010],
  "look-up": [1.82, 510, 1020],
  sky: [1.18, 540, 450],
  beam: [1, 540, 960],
  reaction: [1.75, 485, 1020],
  "alien-return": [1.85, 820, 1020],
  decision: [1.65, 540, 1030],
  escape: [1, 540, 960],
};

const Backdrop: React.FC<{ street?: boolean; t: number }> = ({ street, t }) => (
  <Img
    src={staticFile(
      street ? "world/kazan-clean.png" : "world/courtyard-clean.png",
    )}
    style={{
      position: "absolute",
      width: 1080,
      height: 1920,
      objectFit: "cover",
      scale: 1.04,
      translate: `${Math.sin(t * 0.37) * 3}px 0px`,
      filter: "brightness(.86) saturate(.88)",
    }}
  />
);

const Saucer: React.FC<{ x: number; y: number; w: number; t: number }> = ({
  x,
  y,
  w,
  t,
}) => (
  <Img
    src={staticFile("props/ufo.png")}
    style={{
      position: "absolute",
      left: x,
      top: y + Math.sin(t * 1.3 + x) * 6,
      width: w,
      height: (w * 378) / 915,
    }}
  />
);

const ActionMarks: React.FC<{ t: number; kind: "speed" | "shock" }> = ({
  t,
  kind,
}) => (
  <svg
    width={1080}
    height={1920}
    style={{ position: "absolute", inset: 0, pointerEvents: "none" }}
  >
    {Array.from({ length: kind === "speed" ? 13 : 8 }, (_, i) => {
      const a = i * 2.39996,
        cx = 540,
        cy = kind === "speed" ? 910 : 730;
      const r = kind === "speed" ? 720 + ((t * 490 + i * 103) % 350) : 300;
      return (
        <path
          key={i}
          d={`M${cx + Math.cos(a) * r} ${cy + Math.sin(a) * r}l${Math.cos(a) * 150} ${Math.sin(a) * 150}`}
          stroke={i % 3 === 0 ? "#af2d45" : "#ecdfc6"}
          strokeWidth={i % 3 === 0 ? 6 : 3}
          opacity={kind === "speed" ? 0.4 : 0.85}
        />
      );
    })}
  </svg>
);

const Beam: React.FC<{ t: number }> = ({ t }) => {
  const p = ease((t - B.beam) / 0.28);
  if (p === 0) return null;
  return (
    <svg
      width={1080}
      height={1920}
      style={{ position: "absolute", inset: 0, opacity: p }}
    >
      <defs>
        <linearGradient id="court-beam" x2="0" y2="1">
          <stop stopColor="#e0ffff" stopOpacity=".66" />
          <stop offset="1" stopColor="#57d9e6" stopOpacity=".16" />
        </linearGradient>
      </defs>
      <path d="M370 265H710L1230 1920H-150Z" fill="url(#court-beam)" />
      <path d="M455 265H625L930 1920H150Z" fill="#cbffff" opacity=".08" />
      <ellipse
        cx="540"
        cy="1755"
        rx="780"
        ry="190"
        fill="#83f0ec"
        opacity=".13"
      />
      {Array.from({ length: 16 }, (_, i) => (
        <path
          key={i}
          d={`M${100 + ((i * 137) % 890)} ${400 + ((i * 187 - t * 300 + 18000) % 1250)}v-14`}
          stroke="#dcffff"
          opacity=".46"
          strokeWidth="2"
        />
      ))}
    </svg>
  );
};

const Shadow: React.FC<{ x: number; y: number; scale: number }> = ({
  x,
  y,
  scale,
}) => (
  <svg width={1080} height={1920} style={{ position: "absolute", inset: 0 }}>
    <ellipse
      cx={x}
      cy={y}
      rx={125 * scale}
      ry={19 * scale}
      fill="#11121d"
      opacity=".37"
    />
  </svg>
);

const Street: React.FC<{ t: number; view: View }> = ({ t, view }) => {
  const closeAlien = view === "alien-street";
  const s = closeAlien ? 1.6 : view === "street-run" ? 1 : 1.42;
  const tx = closeAlien ? -500 : view === "street-run" ? 0 : -190;
  return (
    <AbsoluteFill style={{ background: "#343544", overflow: "hidden" }}>
      <div
        style={{
          position: "absolute",
          width: 1080,
          height: 1920,
          scale: s,
          translate: `${tx}px ${s > 1 ? -340 : 0}px`,
          transformOrigin: "0 0",
        }}
      >
        <Backdrop street t={t} />
        <Saucer x={-80 + t * 8} y={15} w={700} t={t} />
        <Saucer x={650 - t * 15} y={390} w={390} t={t + 1} />
        <Saucer x={-30 + t * 11} y={610} w={205} t={t + 2} />
        <Shadow x={790} y={1768} scale={0.65} />
        <SkinnedRig
          who="alien"
          time={t}
          x={790}
          y={1385}
          scale={0.65}
          action="run"
          phase={2.2}
          phone={false}
        />
        <SkinnedRig
          who="alien"
          time={t}
          x={160}
          y={1300}
          scale={0.43}
          action="run"
          phase={0.8}
          phone={false}
        />
        {!closeAlien && (
          <>
            <Shadow x={480} y={1875} scale={0.82} />
            <SkinnedRig
              who="azi"
              time={t}
              x={480 + Math.sin(t * 0.7) * 12}
              y={1400}
              scale={0.82}
              action="run"
              phone={false}
              face="surprise"
            />
          </>
        )}
      </div>
      <ActionMarks t={t} kind="speed" />
    </AbsoluteFill>
  );
};

const Contact: React.FC<{ t: number; door?: boolean }> = ({ t, door }) => {
  const shake = Math.sin(t * 18) * 3;
  return (
    <AbsoluteFill style={{ overflow: "hidden", background: "#292a38" }}>
      <Img
        src={staticFile("world/courtyard-clean.png")}
        style={{
          position: "absolute",
          width: 1080,
          height: 1920,
          objectFit: "cover",
          scale: 1.75,
          translate: "-270px -570px",
          filter: "brightness(.74)",
        }}
      />
      {door && (
        <svg width={1080} height={1920} style={{ position: "absolute" }}>
          <path
            d="M782 493L1080 403V1910H782Z"
            fill="#151820"
            stroke="#0d1017"
            strokeWidth="12"
          />
          <path
            d={`M${804 + shake} 520L1080 435V1885H804Z`}
            fill="#555662"
            stroke="#161821"
            strokeWidth="7"
          />
          <path d="M900 1120V1324" stroke="#1e2029" strokeWidth="35" />
          <path
            d={`M${833 + shake} 1200H930`}
            stroke="#b4bac1"
            strokeWidth="17"
          />
          <path
            d={`M${832 + shake} 1208H930`}
            stroke="#262b36"
            strokeWidth="5"
          />
        </svg>
      )}
      <SkinnedRig
        who="azi"
        time={t}
        x={210}
        y={1530}
        scale={1.0}
        action={door ? "reach" : "gate"}
        mode="notice"
        progress={1}
        phone={false}
        face={door ? "irritated" : "neutral"}
      />
      {!door && (
        <svg
          width={1080}
          height={1920}
          style={{ position: "absolute", translate: `${shake}px 0px` }}
        >
          <path
            d="M742 0Q740 130 825 240L1080 140V1920H787V270"
            fill="#141721"
            fillOpacity=".32"
            stroke="#171922"
            strokeWidth="18"
          />
          {[792, 850, 908, 966, 1024].map((x) => (
            <path
              key={x}
              d={`M${x} 220V1920`}
              stroke="#151821"
              strokeWidth="13"
            />
          ))}
          <path
            d="M775 1070H1080M775 1410H1080"
            stroke="#151821"
            strokeWidth="15"
          />
          <path d="M850 270V1910" stroke="#717884" strokeWidth="2" />
        </svg>
      )}
      <div
        style={{
          position: "absolute",
          left: 795,
          top: 1330,
          fontFamily: "AziComic",
          fontSize: 58,
          color: "#d9d4c7",
          rotate: "-12deg",
          opacity: 0.65 + Math.sin(t * 18) * 0.25,
        }}
      >
        КЛАЦ
      </div>
    </AbsoluteFill>
  );
};

const Slam: React.FC<{ t: number }> = ({ t }) => {
  const p = ease((t - B.escape - 0.85) / 0.15);
  const shake =
    Math.sin((t - B.escape - 1) * 65) *
    9 *
    Math.exp(-Math.max(0, t - B.escape - 1) * 9);
  return (
    <AbsoluteFill style={{ background: "#151823", overflow: "hidden" }}>
      <div
        style={{
          position: "absolute",
          inset: -30,
          background: "#672637",
          border: "23px solid #171621",
          translate: `${(1 - p) * 1150 + shake}px 0px`,
          rotate: `${(1 - p) * -7}deg`,
          transformOrigin: "100% 50%",
        }}
      />
      <svg width={1080} height={1920} style={{ position: "absolute" }}>
        <path d="M760 1010V1350" stroke="#151721" strokeWidth="55" />
        <path d="M610 1160H808" stroke="#adb2ba" strokeWidth="29" />
      </svg>
      {p > 0.85 && (
        <div
          style={{
            position: "absolute",
            left: 155,
            top: 640,
            color: "#f0e1c6",
            fontSize: 230,
            fontFamily: "AziComic",
            rotate: "-13deg",
            scale: 1 + 0.09 * Math.exp(-Math.max(0, t - B.escape - 1) * 6),
            WebkitTextStroke: "5px #19151e",
          }}
        >
          БАМ!
        </div>
      )}
    </AbsoluteFill>
  );
};

const EscapeInsert: React.FC<{ t: number }> = ({ t }) => {
  const dt = t - B.escape;
  const opening = ease((dt - 0.2) / 0.58);
  const lever = ease(dt / 0.15) * (1 - ease((dt - 0.25) / 0.15));
  const edge = 804 + 276 * opening;
  return (
    <AbsoluteFill style={{ background: "#272a35", overflow: "hidden" }}>
      <div
        style={{
          position: "absolute",
          width: 1080,
          height: 1920,
          scale: 1.7,
          translate: "-740px -1150px",
          transformOrigin: "0 0",
        }}
      >
        <Backdrop t={t} />
        <svg width={1080} height={1920} style={{ position: "absolute" }}>
          <path
            d="M782 493L1080 403V1910H782Z"
            fill="#151d27"
            stroke="#10131d"
            strokeWidth="12"
          />
          <path
            d={`M${edge} ${520 + 80 * opening}L1080 435V1885L${edge} ${1885 - 120 * opening}Z`}
            fill="#672637"
            stroke="#181622"
            strokeWidth="7"
          />
          <path
            d={`M${900 + 180 * opening} 1120V1324`}
            stroke="#191923"
            strokeWidth={35 * (1 - opening)}
          />
          <path
            d={`M${833 + 247 * opening} ${1200 + lever * 12}L${930 + 150 * opening} 1200`}
            stroke="#bfc1c7"
            strokeWidth="17"
          />
          <path
            d={`M${833 + 247 * opening} ${1208 + lever * 12}L${930 + 150 * opening} 1208`}
            stroke="#30303c"
            strokeWidth="4"
          />
        </svg>
        <SkinnedRig
          who="azi"
          time={t}
          x={210}
          y={1530 + lever * 9}
          scale={1}
          action="reach"
          actionProgress={dt}
          onlyArm
          phone={false}
        />
      </div>
    </AbsoluteFill>
  );
};

const Courtyard: React.FC<{ t: number; view: View }> = ({ t, view }) => {
  const cam = cameras[view] ?? [1, 540, 960];
  const s = cam[0];
  // Clamp the camera to the full-bleed drawing: no unpainted borders during pans.
  const tx = Math.max(1080 - 1080 * s, Math.min(0, 540 - cam[1] * s));
  const ty = Math.max(1920 - 1920 * s, Math.min(0, 960 - cam[2] * s));
  const escape = ease((t - B.escape) / 0.83);
  const entering = ease((t - B.enter) / 0.85);
  const x =
    view === "annoyed"
      ? 420
      : view === "brake"
        ? 335
        : t < B.quiet
          ? mix(170, 480, entering)
          : mix(480, 995, escape);
  const y = mix(1420, 1200, escape),
    scale = mix(0.78, 0.35, escape);
  const chasing = t < B.quiet || (t >= B.beam && t < B.escape + 0.8);
  const sky = view === "sky";
  const alienClose = view === "alien-run" || view === "alien-return";
  const aliens =
    chasing && !sky ? (
      <>
        <Shadow x={780} y={1756} scale={0.62} />
        <SkinnedRig
          who="alien"
          time={t}
          x={780 + Math.sin(t * 0.8) * 16}
          y={1390}
          scale={0.62}
          action="run"
          phase={1.9}
          phone={false}
        />
        <Shadow x={180} y={1584} scale={0.43} />
        <SkinnedRig
          who="alien"
          time={t}
          x={180}
          y={1330}
          scale={0.43}
          action="run"
          phase={0.5}
          phone={false}
        />
      </>
    ) : null;
  return (
    <AbsoluteFill style={{ background: "#343442", overflow: "hidden" }}>
      <div
        style={{
          position: "absolute",
          width: 1080,
          height: 1920,
          scale: s,
          translate: `${tx}px ${ty}px`,
          transformOrigin: "0 0",
        }}
      >
        <Backdrop t={t} />
        {t > B.sky - 0.15 && (
          <Saucer
            x={50}
            y={-120 + ease((t - B.sky + 0.1) / 0.6) * 185}
            w={1000}
            t={t}
          />
        )}
        <Beam t={t} />
        {escape <= 0.2 && aliens}
        {!sky && !alienClose && t < B.escape + 0.83 && (
          <>
            <Shadow x={x} y={y + 580 * scale} scale={scale} />
            <SkinnedRig
              who="azi"
              time={t}
              x={x}
              y={y}
              scale={scale}
              action={
                t < B.quiet || t >= B.escape
                  ? "run"
                  : view === "brake"
                    ? "hide"
                    : t >= B.beam
                      ? "flinch"
                      : "idle"
              }
              mode={view === "decision" ? "quip" : "notice"}
              progress={1}
              phone={false}
              rotation={view === "look-up" ? -4 : 0}
              face={
                view === "annoyed" || view === "decision"
                  ? "irritated"
                  : t >= B.beam ||
                      t < B.quiet ||
                      view === "brake" ||
                      view === "look-up"
                    ? "surprise"
                    : "neutral"
              }
            />
          </>
        )}
        {escape > 0.2 && aliens}
        {view === "brake" && (
          <svg width={1080} height={1920} style={{ position: "absolute" }}>
            <path
              d="M0 240L262 370V1920H0Z"
              fill="#242633"
              stroke="#151822"
              strokeWidth="9"
            />
            <path
              d="M262 370L282 386V1920H262Z"
              fill="#3d3b47"
              stroke="#171822"
              strokeWidth="4"
            />
          </svg>
        )}
        {t >= B.escape && (
          <svg width={1080} height={1920} style={{ position: "absolute" }}>
            <path d="M952 998L1040 963V1388L952 1377Z" fill="#101520" />
            <path
              d={`M${952 - ease((t - B.escape) / 0.22) * 75} ${998 + ease((t - B.escape) / 0.22) * 29}L952 998V1377L${952 - ease((t - B.escape) / 0.22) * 75} ${1377 + ease((t - B.escape) / 0.22) * 40}Z`}
              fill="#622c3a"
              stroke="#181824"
              strokeWidth="5"
            />
          </svg>
        )}
      </div>
      {(view === "run" || view === "alien-run" || view === "escape") && (
        <ActionMarks t={t} kind="speed" />
      )}
      {view === "look-up" && <ActionMarks t={t} kind="shock" />}
    </AbsoluteFill>
  );
};

const FrameView: React.FC<{ t: number; view: View }> = ({ t, view }) =>
  view.startsWith("street") || view === "alien-street" ? (
    <Street t={t} view={view} />
  ) : view === "gate" || view === "door" ? (
    <Contact t={t} door={view === "door"} />
  ) : view === "escape" ? (
    <EscapeInsert t={t} />
  ) : view === "slam" ? (
    <Slam t={t} />
  ) : (
    <Courtyard t={t} view={view} />
  );

const Caption: React.FC<{ t: number }> = ({ t }) => {
  const line = timing.captions.find((l) => t >= l.from && t < l.to);
  if (!line) return null;
  const words = line.text.split(" ");
  const lines = [""];
  for (const word of words) {
    const i = lines.length - 1;
    if (lines[i].length && lines[i].length + word.length > 30) lines.push(word);
    else lines[i] += (lines[i] ? " " : "") + word;
  }
  const w = Math.min(
    780,
    Math.max(290, Math.max(...lines.map((l) => l.length)) * 20 + 74),
  );
  const h = lines.length * 50 + 48;
  const speech = line.cue === 7;
  const p = ease((t - line.from) / 0.1);
  return (
    <div
      style={{
        position: "absolute",
        left: 55,
        top: speech ? 1360 : 95,
        width: w,
        height: h,
        opacity: p,
        scale: mix(0.94, 1, p),
        transformOrigin: "12% 50%",
      }}
    >
      <svg
        width={w}
        height={h + 40}
        style={{ position: "absolute", overflow: "visible" }}
      >
        {speech ? (
          <>
            <ellipse
              cx={w / 2}
              cy={h / 2}
              rx={w / 2}
              ry={h / 2}
              fill="#f0e4ca"
              stroke="#181722"
              strokeWidth="4"
            />
            <path
              d="M95 7L51 -50L137 3"
              fill="#f0e4ca"
              stroke="#181722"
              strokeWidth="4"
            />
          </>
        ) : (
          <path
            d={`M6 6L${w - 10} 0L${w} ${h - 5}L0 ${h}Z`}
            fill="#f0e4ca"
            stroke="#181722"
            strokeWidth="4"
          />
        )}
      </svg>
      <div
        style={{
          position: "absolute",
          inset: 0,
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          alignItems: "center",
          fontFamily: "AziComic",
          fontSize: 44,
          lineHeight: "50px",
          color: "#25212c",
        }}
      >
        {lines.map((line, i) => (
          <div key={i}>{line}</div>
        ))}
      </div>
    </div>
  );
};

export const Scene2: React.FC = () => {
  const f = useCurrentFrame(),
    { fps } = useVideoConfig(),
    t = f / fps;
  let index = scene2Cuts.length - 1;
  while (index > 0 && t < scene2Cuts[index].t) index--;
  const cut = scene2Cuts[index],
    previous = scene2Cuts[Math.max(0, index - 1)];
  const p = index === 0 || cut.edit === "cut" ? 1 : ease((t - cut.t) / 0.16);
  const clip =
    p === 1
      ? undefined
      : cut.edit === "slash"
        ? `polygon(0 0,${p * 130}% 0,${p * 130 - 30}% 100%,0 100%)`
        : cut.edit === "shutter"
          ? `inset(${(1 - p) * 50}% 0 ${(1 - p) * 50}% 0)`
          : `inset(0 0 0 ${(1 - p) * 100}%)`;
  return (
    <AbsoluteFill style={{ background: "#262533", overflow: "hidden" }}>
      <Audio src={staticFile("audio/scene2-mix.wav")} premountFor={fps} />
      {p < 1 && <FrameView t={t} view={previous.view} />}
      <div style={{ position: "absolute", inset: 0, clipPath: clip }}>
        <FrameView t={t} view={cut.view} />
      </div>
      <Caption t={t} />
      {t < 1.25 && (
        <div
          style={{
            position: "absolute",
            left: 62,
            top: 335,
            fontFamily: "AziComic",
            fontSize: 62,
            color: "#f0dfc6",
            rotate: "-5deg",
            textShadow: "3px 4px #571e33",
          }}
        >
          ПРАВИЛО 2
        </div>
      )}
    </AbsoluteFill>
  );
};
