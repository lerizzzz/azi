import { Composition, Folder } from "remotion";
import { SkinCheck } from "./SkinnedRig";
import { Scene1 } from "./Scene1";
import { Scene2 } from "./Scene2";
export const RemotionRoot = () => (
  <>
    <Composition
      id="Scene1"
      component={Scene1}
      durationInFrames={1030}
      fps={30}
      width={1080}
      height={1920}
    />
    <Composition
      id="Scene2"
      component={Scene2}
      durationInFrames={731}
      fps={30}
      width={1080}
      height={1920}
    />
    <Folder name="Rig-Checks">
      <Composition
        id="AziRig"
        component={SkinCheck}
        durationInFrames={180}
        fps={30}
        width={1080}
        height={1920}
        defaultProps={{ who: "azi" }}
      />
      <Composition
        id="ManRig"
        component={SkinCheck}
        durationInFrames={180}
        fps={30}
        width={1080}
        height={1920}
        defaultProps={{ who: "man" }}
      />
      <Composition
        id="AlienRig"
        component={SkinCheck}
        durationInFrames={180}
        fps={30}
        width={1080}
        height={1920}
        defaultProps={{ who: "alien" }}
      />
    </Folder>
  </>
);
