import fs from "node:fs";
import { spawnSync } from "node:child_process";

// The reviewed door insert replaces only frames 686..717. The source composition
// already contains this final edit; a fresh full render gives the same timeline.
const base = "review/scene2-layered-v02.mp4";
const patch = "review/scene2-escape-patch.mp4";
const output = "out/scene2-remotion-1080.mp4";
const convert = (path) => {
  const r = spawnSync(
    "ffprobe",
    ["-v", "error", "-show_streams", "-of", "json", path],
    { encoding: "utf8" },
  );
  if (r.status !== 0) throw Error(r.stderr);
  const v = JSON.parse(r.stdout).streams.find((s) => s.codec_type === "video");
  return `scale=in_range=${v.color_range === "pc" ? "pc" : "tv"}:out_range=tv:in_color_matrix=${v.color_space === "bt709" ? "bt709" : "bt601"}:out_color_matrix=bt709,format=yuv420p,setsar=1`;
};
fs.mkdirSync("out", { recursive: true });
const filter =
  `[0:v]trim=end_frame=686,setpts=PTS-STARTPTS,${convert(base)}[a];` +
  `[1:v]trim=end_frame=32,setpts=PTS-STARTPTS,${convert(patch)}[b];` +
  `[0:v]trim=start_frame=718,setpts=PTS-STARTPTS,${convert(base)}[c];` +
  "[a][b][c]concat=n=3:v=1:a=0[v]";
const r = spawnSync(
  "ffmpeg",
  [
    "-y",
    "-hide_banner",
    "-loglevel",
    "error",
    "-i",
    base,
    "-i",
    patch,
    "-filter_complex",
    filter,
    "-map",
    "[v]",
    "-map",
    "0:a:0",
    "-c:v",
    "libx264",
    "-preset",
    "fast",
    "-threads",
    "4",
    "-profile:v",
    "baseline",
    "-level:v",
    "4.0",
    "-crf",
    "18",
    "-r",
    "30",
    "-frames:v",
    "731",
    "-pix_fmt",
    "yuv420p",
    "-color_range",
    "tv",
    "-colorspace",
    "bt709",
    "-color_trc",
    "bt709",
    "-color_primaries",
    "bt709",
    "-c:a",
    "copy",
    "-movflags",
    "+faststart",
    output,
  ],
  { stdio: "inherit" },
);
if (r.status !== 0) process.exit(r.status || 1);
console.log("Assembled:", output);
