"""Validate exported media, exact dialogue, packaging and review frames."""
from pathlib import Path
import hashlib, json, subprocess
R = Path(__file__).resolve().parents[1]
movie = R / 'out/scene2-remotion-1080.mp4'
probe = json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(movie)]))
video = next(s for s in probe['streams'] if s['codec_type']=='video')
audio = next(s for s in probe['streams'] if s['codec_type']=='audio')
assert (video['width'],video['height'],video['r_frame_rate'],video['codec_name'],video['pix_fmt']) == (1080,1920,'30/1','h264','yuv420p')
assert int(video['nb_read_frames']) == 731 and audio['codec_name']=='aac'
r = subprocess.run(['ffmpeg','-v','error','-i',str(movie),'-f','null','-'],capture_output=True,text=True,check=True)
assert not r.stderr
timing = json.loads((R/'src/scene2-timing.json').read_text())
source = json.loads((R.parent/'animation/film-v01/dialogue-source.json').read_text())
for cue in [5,6,7]:
    assert ' '.join(c['text'] for c in timing['captions'] if c['cue']==cue) == source[cue-1]['text']
assert all(c['from'] < c['to'] for c in timing['captions'])
assert timing['captions'][-1]['to'] < timing['duration']
(R/'review/scene2-decoded').mkdir(exist_ok=True)
frames = [0,66,138,174,240,351,459,522,543,582,639,688,695,703,710,718,730]
expr = '+'.join(f'eq(n\\,{n})' for n in frames)
subprocess.run(['ffmpeg','-y','-loglevel','error','-i',str(movie),'-vf','select='+expr+',scale=540:960','-fps_mode','vfr','-q:v','2',str(R/'review/scene2-decoded/frame-%02d.jpg')],check=True)
report = {'engine':'Remotion 4.0.539','scene':2,'width':1080,'height':1920,'fps':30,'frames':731,
          'duration_seconds':float(probe['format']['duration']),'codec':video['codec_name'],
          'pixel_format':video['pix_fmt'],'audio':audio['codec_name'],'full_decode_no_errors':True,
          'scene_dialogue_verbatim_and_ordered':True,'all_voice_tracks_fit':True,
          'cut_count':20,'working_rigs':['azi','man','alien'],'synthetic_test_voice':True,
          'perceptual_audio_review_performed':False,'user_approval_received':False,
          'sha256':hashlib.sha256(movie.read_bytes()).hexdigest()}
(R/'review/scene2-validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps(report,ensure_ascii=False,indent=2))
