"""Exact user dialogue, local temporary speech and original scene-2 sound design."""
from pathlib import Path
import json, math, subprocess, wave
import numpy as np
from scipy.signal import resample_poly

ROOT = Path(__file__).resolve().parents[1]
SR = 48000
AUDIO = ROOT / 'public/audio'
ENGINE = ROOT.parent / '.runtime/RHVoice/local/bin/RHVoice-test'
original = json.loads((ROOT.parent / 'animation/film-v01/dialogue-source.json').read_text())
parts = [
    (5, 'Второе.', .22),
    (5, 'Если тебя заметили — прячься.', .28),
    (5, 'Желательно туда, где тебя не найдут', .55),
    (6, 'В Питере, кстати, с этим проблем нет.', .28),
    (6, 'Здесь можно зайти во двор', .24),
    (6, 'и самой себя больше никогда не найти', .60),
    (7, 'А.', .48),
    (7, 'Ну для них, видимо, навигация работает', .45),
]
for cue in [5, 6, 7]:
    assert ' '.join(t for c, t, _ in parts if c == cue) == original[cue - 1]['text']

def read(path):
    with wave.open(str(path)) as w:
        rate = w.getframerate()
        a = np.frombuffer(w.readframes(w.getnframes()), dtype='<i2').astype(np.float32) / 32768
    a = resample_poly(a, SR, rate)
    a *= min(2.8, .12 / max(.001, float(np.sqrt(np.mean(a * a)))))
    n = min(240, len(a) // 4)
    a[:n] *= np.linspace(0, 1, n)
    a[-n:] *= np.linspace(1, 0, n)
    return a

cursor = .35
captions = []
samples = []
for k, (cue, text, pause) in enumerate(parts):
    if cue == 7 and parts[k - 1][0] != 7:
        cursor += 1.30  # Look up, then beam and a silent reaction before the punchline.
    inp, out = AUDIO / f's2-{k:02}.txt', AUDIO / f's2-{k:02}.wav'
    inp.write_text(text)
    if not out.exists():
        subprocess.run([str(ENGINE), '-p', 'Elena', '-r', '78', '-t', '84', '-i', str(inp), '-o', str(out)], check=True)
    a = read(out)
    captions.append({'cue': cue, 'speaker': 'АЗИ', 'text': text, 'from': cursor, 'to': cursor + len(a) / SR, 'file': 'audio/' + out.name})
    samples.append(a)
    cursor = captions[-1]['to'] + pause
    print(round(captions[-1]['from'], 2), round(captions[-1]['to'], 2), text, flush=True)

six = [r for r in captions if r['cue'] == 6]
seven = [r for r in captions if r['cue'] == 7]
beats = {'rule': .35, 'chase': 1.9, 'enter': 4.1,
         'quiet': six[0]['from'] - .35, 'gate': six[1]['from'] - .15,
         'door': six[2]['from'] + 1.15, 'sky': six[-1]['to'] + .25,
         'beam': seven[0]['from'] - .70, 'quip': seven[0]['from'],
         'escape': seven[-1]['to'] + .35}
frames = math.ceil((beats['escape'] + 1.5) * 30)
data = {'fps': 30, 'width': 1080, 'height': 1920, 'frames': frames,
        'duration': frames / 30, 'captions': captions, 'beats': beats,
        'voice': {'engine': 'RHVoice', 'voice': 'Elena', 'rate': 78, 'pitch': 84, 'temporary': True}}
for path in [ROOT / 'src/scene2-timing.json', ROOT / 'public/scene2-timing.json']:
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2))

mix = np.zeros(round(SR * frames / 30), np.float32)
rng = np.random.default_rng(208)
def add(t, a, gain=1):
    i = round(t * SR)
    if i < 0 or i >= len(mix):
        return
    n = min(len(a), len(mix) - i)
    mix[i:i+n] += a[:n] * gain
def tone(t, duration, freq, gain=.03, decay=3):
    z = np.arange(round(duration * SR)) / SR
    add(t, np.sin(2 * np.pi * freq * z) * np.exp(-decay * z) * np.minimum(1, z / .008), gain)
def noise(t, duration, gain=.04):
    z = np.arange(round(duration * SR)) / SR
    a = np.convolve(rng.normal(0, 1, len(z)), np.ones(10) / 10, 'same')
    add(t, a * np.sin(np.pi * z / duration) ** 2, gain)

for n, t in enumerate(np.arange(0, frames / 30, 60 / 100)):
    tone(t, .30, [55, 65.406, 55, 73.416][n % 4], .018, 8)
    if n % 2 == 0:
        tone(t, .12, 68, .035, 25)
    if n % 4 == 2:
        noise(t, .075, .025)
for t in np.arange(.5, beats['quiet'], .31):
    tone(t, .055, 90, .035, 45)
    noise(t, .035, .07)
for t in [1.9, 4.1, beats['gate'], beats['door'], beats['sky'], beats['beam'], beats['escape']]:
    noise(t, .18, .06)
for base in [beats['gate'] + .25, beats['door'] + .15]:
    for i in range(4):
        tone(base + i * .08, .12, 280 + i * 43, .025, 28)
        noise(base + i * .08, .04, .07)
z = np.arange(round((beats['escape'] - beats['beam']) * SR)) / SR
add(beats['beam'], (np.sin(2*np.pi*67*z) + .35*np.sin(2*np.pi*134*z)) * np.minimum(1, z/.35), .025)
tone(beats['escape'] + .95, .25, 72, .12, 23)
noise(beats['escape'] + .95, .08, .13)
for row, a in zip(captions, samples):
    add(row['from'], a)
mix[-4800:] *= np.linspace(1, 0, 4800)
mix *= min(1, .90 / max(.001, float(abs(mix).max())))
with wave.open(str(AUDIO / 'scene2-mix.wav'), 'wb') as w:
    w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
    w.writeframes((mix * 32767).astype('<i2').tobytes())
print('Scene2', frames, 'frames', frames / 30, 'seconds', beats)
