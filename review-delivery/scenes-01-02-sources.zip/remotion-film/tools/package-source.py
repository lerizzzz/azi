from pathlib import Path
import json,zipfile,hashlib,sys
R=Path(__file__).resolve().parents[1];P=R.parent;out=Path(sys.argv[1]) if len(sys.argv)>1 else P/'exports/azi-remotion-scenes-01-02-sources.zip'
files=[]
for name in ['README.md','package.json','package-lock.json','tsconfig.json','eslint.config.mjs','remotion.config.ts']:files.append(R/name)
for folder in ['src','tools','public','licenses']:
 files.extend(x for x in (R/folder).rglob('*') if x.is_file() and '__pycache__' not in str(x))
files.extend(x for x in (R/'review').glob('*.json'))
files += [P/'docs/SCREENPLAY_ALIENS_v02.md',P/'animation/film-v01/dialogue-source.json']
files.extend(x for x in (P/'production/remotion-scene2').rglob('*') if x.is_file())
manifest=[]
for f in files:manifest.append({'path':str(f.relative_to(P)),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
(R/'source-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2));files.append(R/'source-manifest.json')
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for f in files:z.write(f,str(f.relative_to(P)))
 z.writestr('README-FIRST.txt','Послойный проект Remotion AZI.\nЧитайте remotion-film/README.md.\n56 графических слоёв, атласы, риги Ази/мужчины/пришельца, две сцены, WAV, шрифты и код включены.\nДля Леры и мастера готовы изображения, ригирование впереди.\nЭто рабочая версия для оценки двух сцен; полный фильм не завершён.\nПромежуточные MP4, node_modules и модели RHVoice не включены. Готовые WAV включены.\n')
with zipfile.ZipFile(out) as z:assert z.testzip() is None
print('Source ZIP:',out.stat().st_size,'bytes;',len(files),'files')
