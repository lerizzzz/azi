import { bundle } from "@remotion/bundler";
import {
  openBrowser,
  selectComposition,
  renderStill,
} from "@remotion/renderer";
import path from "node:path";
import fs from "node:fs";
fs.mkdirSync("review/scene2", { recursive: true });
if (
  fs.existsSync("review/bundle2/public") &&
  fs.lstatSync("review/bundle2/public").isSymbolicLink()
)
  fs.unlinkSync("review/bundle2/public");
const serveUrl = await bundle({
  entryPoint: path.resolve("src/index.ts"),
  outDir: path.resolve("review/bundle2"),
  rspack: true,
  symlinkPublicDir: true,
});
const browser = await openBrowser("chrome", {
  browserExecutable: "/usr/bin/chromium",
  chromiumOptions: { gl: "swangle" },
});
try {
  const composition = await selectComposition({
    serveUrl,
    id: "Scene2",
    puppeteerInstance: browser,
  });
  const times = process.argv.slice(2).map(Number);
  for (const sec of times.length
    ? times
    : [0, 2.2, 4.6, 5.8, 8, 11.7, 15.3, 17.4, 18.1, 19.4, 21.3, 23.3, 24.1]) {
    await renderStill({
      serveUrl,
      composition,
      frame: Math.round(sec * 30),
      output: `review/scene2/frame-${sec}.png`,
      imageFormat: "png",
      scale: 0.5,
      puppeteerInstance: browser,
    });
    console.log("Scene 2 review", sec);
  }
} finally {
  await browser.close({ silent: true });
}
